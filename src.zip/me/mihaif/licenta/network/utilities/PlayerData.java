package me.mihaif.licenta.network.utilities;

public class PlayerData {
	public String username;
	public int avatarID;
	public PlayerData(String username, int avatarID) {
		this.username = username;
		this.avatarID = avatarID;
	}
}
