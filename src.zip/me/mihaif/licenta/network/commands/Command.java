package me.mihaif.licenta.network.commands;

public interface Command {
	
}
