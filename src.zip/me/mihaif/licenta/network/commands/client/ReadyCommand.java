package me.mihaif.licenta.network.commands.client;

public class ReadyCommand implements ClientCommand{

	@Override
	public void send(Object... payload) {
		// TODO Auto-generated method stub
		
	}

}
