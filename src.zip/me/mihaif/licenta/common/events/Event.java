package me.mihaif.licenta.common.events;

public interface Event {
	
}
