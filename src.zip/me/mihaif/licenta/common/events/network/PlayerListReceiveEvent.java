package me.mihaif.licenta.common.events.network;


public class PlayerListReceiveEvent implements NetworkEvent{
	
	
	
}
