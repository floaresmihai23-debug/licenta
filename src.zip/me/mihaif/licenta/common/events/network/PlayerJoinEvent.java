package me.mihaif.licenta.common.events.network;


public class PlayerJoinEvent implements NetworkEvent{
	
}
