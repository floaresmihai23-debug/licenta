package me.mihaif.licenta.common.events.network;


public class ConnectionSuccessfulEvent implements NetworkEvent{

}
