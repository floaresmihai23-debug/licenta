package me.mihaif.licenta.common.events.network;

public class StartEvent implements NetworkEvent{

}
