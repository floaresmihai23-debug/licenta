package me.mihaif.licenta.common.events.network;

import me.mihaif.licenta.common.events.Event;

public interface NetworkEvent extends Event {

}
