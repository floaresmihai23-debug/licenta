package me.mihaif.licenta.common.events.ui;

import me.mihaif.licenta.common.events.Event;

public interface UIEvent extends Event{

}
