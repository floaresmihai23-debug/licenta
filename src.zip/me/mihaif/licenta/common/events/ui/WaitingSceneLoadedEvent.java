package me.mihaif.licenta.common.events.ui;

public class WaitingSceneLoadedEvent implements UIEvent{

}
